package ly.najah.maktabi

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.print.PdfExporter
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var db: Db
    private var holder: WebView? = null          // نبقي مرجعاً لـ WebView الطباعة حتى لا يُحذف أثناء العمل
    private var pendingBackup: String? = null

    // حفظ النسخة الاحتياطية في مكان يختاره المستخدم (التنزيلات، Drive، ...)
    private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val data = pendingBackup
        pendingBackup = null
        if (uri != null && data != null) {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
                    ?: throw Exception("تعذر فتح الملف")
                db.setSetting("last_backup", Db.today())
                emit("backup", true, "تم حفظ النسخة الاحتياطية")
            } catch (e: Exception) {
                emit("msg", false, "فشل حفظ النسخة: ${e.message}")
            }
        }
    }

    // استعادة نسخة احتياطية من ملف
    private val pickBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                    ?: throw Exception("تعذر قراءة الملف")
                File(filesDir, "pre-restore.json").writeText(db.exportJson())   // نسخة أمان قبل الاستبدال
                val n = db.restore(text)
                emit("restored", true, "تمت استعادة $n فاتورة")
            } catch (e: Exception) {
                emit("msg", false, "ملف النسخة غير صالح: ${e.message}")
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        db = Db(applicationContext)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowContentAccess = false
            settings.textZoom = 100
            settings.setSupportZoom(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    !request.url.toString().startsWith("file:///android_asset/")
            }
            addJavascriptInterface(Bridge(), "Android")
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }

        // مساحتان لحواف النظام (شريط الحالة والتنقل / لوحة المفاتيح) بدل أن تغطي الواجهة
        val top = View(this).apply { setBackgroundColor(0xFF145B98.toInt()); layoutParams = LinearLayout.LayoutParams(-1, 0) }
        val bottom = View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF4F7FA.toInt())
            addView(top); addView(web); addView(bottom)
        }
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = ins.getInsets(WindowInsetsCompat.Type.ime())
            top.layoutParams.height = bars.top
            bottom.layoutParams.height = maxOf(bars.bottom, ime.bottom)
            root.requestLayout()
            WindowInsetsCompat.CONSUMED
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.goBack ? window.goBack() : false") { r -> if (r != "true") finish() }
            }
        })

        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        holder = null
        super.onDestroy()
    }

    /** إشعار الواجهة بنتيجة عملية غير متزامنة (حفظ/استعادة/PDF). */
    private fun emit(event: String, ok: Boolean, msg: String) {
        val p = JSONObject().put("ok", ok).put("msg", msg)
        runOnUiThread { web.evaluateJavascript("window.onNative && window.onNative('$event', $p)", null) }
    }

    // ---------- الطباعة و PDF ----------

    private fun printAttrs() = PrintAttributes.Builder()
        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
        .setResolution(PrintAttributes.Resolution("pdf", "pdf", 300, 300))
        .setMinMargins(PrintAttributes.Margins(472, 472, 472, 472))   // ≈ 12 مم
        .build()

    private fun renderHtml(html: String, block: (WebView) -> Unit) = runOnUiThread {
        val w = WebView(this)
        var fired = false
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                if (!fired) { fired = true; block(view) }
            }
        }
        holder = w
        w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private fun printHtml(html: String, title: String) = renderHtml(html) { w ->
        val pm = getSystemService(PRINT_SERVICE) as PrintManager
        pm.print(title, w.createPrintDocumentAdapter(title), printAttrs())
    }

    private fun sharePdf(html: String, rawName: String) = renderHtml(html) { w ->
        val name = rawName.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val dir = File(cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "$name.pdf")
        PdfExporter(w.createPrintDocumentAdapter(name), printAttrs()).export(file) { done ->
            if (!done) {
                emit("msg", false, "تعذر إنشاء ملف PDF")
            } else {
                val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "مشاركة الفاتورة"))
            }
        }
    }

    // ---------- الجسر بين الواجهة (JavaScript) والتطبيق ----------

    inner class Bridge {
        @JavascriptInterface
        fun call(method: String, args: String): String = try {
            val a = JSONObject(args)
            when (method) {
                "getAll" -> db.getAll()
                "saveInvoice" -> db.saveInvoice(a)
                "addPayment" -> db.addPayment(a)
                "cancelInvoice" -> db.cancelInvoice(a)
                "saveExpense" -> db.saveExpense(a)
                "deleteExpense" -> db.delete("expenses", a.getLong("id"))
                "saveService" -> db.saveService(a)
                "deleteService" -> db.delete("services", a.getLong("id"))
                "saveSettings" -> db.saveSettings(a)
                "exportBackup" -> {
                    runOnUiThread {
                        pendingBackup = db.exportJson()
                        createBackup.launch("maktabi-backup-${Db.today()}.json")
                    }
                    ok()
                }
                "pickBackup" -> { runOnUiThread { pickBackup.launch(arrayOf("*/*")) }; ok() }
                "print" -> { printHtml(a.getString("html"), a.getString("title")); ok() }
                "sharePdf" -> { sharePdf(a.getString("html"), a.getString("name")); ok() }
                else -> err("طلب غير معروف")
            }.toString()
        } catch (e: Exception) {
            err(e.message ?: "خطأ غير متوقع").toString()
        }
    }
}
