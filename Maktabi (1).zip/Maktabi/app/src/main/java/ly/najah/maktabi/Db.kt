package ly.najah.maktabi

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

fun ok(): JSONObject = JSONObject().put("ok", true)
fun err(msg: String): JSONObject = JSONObject().put("ok", false).put("error", msg)

/**
 * قاعدة البيانات المحلية (SQLite).
 * كل المبالغ تُخزَّن كأعداد صحيحة بالدرهم (1 دينار = 1000 درهم) لتفادي أخطاء الكسور العشرية.
 */
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "maktabi.db", null, 1) {

    companion object {
        fun today(): String = LocalDate.now().toString()
        fun nowTime(): String = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH))

        val DEFAULT_SERVICES = listOf(
            "تصوير أبيض وأسود", "تصوير ملون", "طباعة أبيض وأسود", "طباعة ملونة",
            "تغليف وتجليد", "مسح ضوئي (سكانر)", "خدمات أخرى"
        )
        val DEFAULT_SETTINGS = linkedMapOf(
            "office_name" to "مكتب النجاح",
            "office_desc" to "للطباعة والتصوير",
            "address" to "",
            "phone" to "",
            "footer" to "شكراً لتعاملكم مع مكتب النجاح",
            "currency" to "د.ل",
            "next_num" to "1",
            "last_backup" to ""
        )
        private val EDITABLE = setOf("office_name", "office_desc", "address", "phone", "footer", "currency")

        // الأعمدة المسموح بها عند الاستعادة (بهذا الترتيب: الآباء قبل الأبناء)
        private val COLS = linkedMapOf(
            "settings" to listOf("k", "v"),
            "services" to listOf("id", "name"),
            "invoices" to listOf("id", "num", "date", "time", "customer", "phone", "total", "paid", "method", "notes", "status"),
            "items" to listOf("id", "invoice_id", "name", "qty", "price", "total"),
            "payments" to listOf("id", "invoice_id", "date", "amount", "method"),
            "expenses" to listOf("id", "name", "amount", "date", "category", "notes")
        )
        private val DATE_RE = Regex("""\d{4}-\d{2}-\d{2}""")
    }

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")
        db.execSQL(
            """CREATE TABLE invoices(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                num INTEGER NOT NULL UNIQUE,
                date TEXT NOT NULL, time TEXT NOT NULL,
                customer TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '',
                total INTEGER NOT NULL, paid INTEGER NOT NULL DEFAULT 0,
                method TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'active')"""
        )
        db.execSQL(
            """CREATE TABLE items(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
                name TEXT NOT NULL, qty REAL NOT NULL, price INTEGER NOT NULL, total INTEGER NOT NULL)"""
        )
        db.execSQL(
            """CREATE TABLE payments(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
                date TEXT NOT NULL, amount INTEGER NOT NULL, method TEXT NOT NULL DEFAULT '')"""
        )
        db.execSQL(
            """CREATE TABLE expenses(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL, amount INTEGER NOT NULL, date TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '')"""
        )
        db.execSQL("CREATE INDEX idx_inv_date ON invoices(date)")
        db.execSQL("CREATE INDEX idx_items_inv ON items(invoice_id)")
        db.execSQL("CREATE INDEX idx_pay_inv ON payments(invoice_id)")
        db.execSQL("CREATE INDEX idx_exp_date ON expenses(date)")
        for (s in DEFAULT_SERVICES) db.execSQL("INSERT INTO services(name) VALUES(?)", arrayOf<Any?>(s))
        ensureDefaults(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private fun ensureDefaults(db: SQLiteDatabase) {
        for ((k, v) in DEFAULT_SETTINGS) db.execSQL("INSERT OR IGNORE INTO settings(k,v) VALUES(?,?)", arrayOf<Any?>(k, v))
    }

    // ---------- أدوات مساعدة ----------

    private fun Cursor.toJson(): JSONArray {
        val arr = JSONArray()
        use {
            while (moveToNext()) {
                val o = JSONObject()
                for (i in 0 until columnCount) {
                    val n = getColumnName(i)
                    when (getType(i)) {
                        Cursor.FIELD_TYPE_INTEGER -> o.put(n, getLong(i))
                        Cursor.FIELD_TYPE_FLOAT -> o.put(n, getDouble(i))
                        Cursor.FIELD_TYPE_NULL -> o.put(n, JSONObject.NULL)
                        else -> o.put(n, getString(i))
                    }
                }
                arr.put(o)
            }
        }
        return arr
    }

    fun getSetting(k: String): String =
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k)).use {
            if (it.moveToFirst()) it.getString(0) else ""
        }

    fun setSetting(k: String, v: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", arrayOf<Any?>(k, v))
    }

    // ---------- القراءة ----------

    fun getAll(): JSONObject {
        val db = readableDatabase
        val settings = JSONObject()
        db.rawQuery("SELECT k,v FROM settings", null).use { while (it.moveToNext()) settings.put(it.getString(0), it.getString(1)) }

        val invoices = db.rawQuery(
            "SELECT id,num,date,time,customer,phone,total,paid,method,notes,status FROM invoices ORDER BY num DESC", null
        ).toJson()
        val byId = HashMap<Long, JSONObject>()
        for (i in 0 until invoices.length()) {
            val o = invoices.getJSONObject(i)
            o.put("items", JSONArray()).put("payments", JSONArray())
            byId[o.getLong("id")] = o
        }
        val items = db.rawQuery("SELECT invoice_id,name,qty,price,total FROM items ORDER BY id", null).toJson()
        for (i in 0 until items.length()) {
            val r = items.getJSONObject(i)
            byId[r.getLong("invoice_id")]?.getJSONArray("items")?.put(r)
        }
        val pays = db.rawQuery("SELECT invoice_id,date,amount,method FROM payments ORDER BY id", null).toJson()
        for (i in 0 until pays.length()) {
            val r = pays.getJSONObject(i)
            byId[r.getLong("invoice_id")]?.getJSONArray("payments")?.put(r)
        }
        return ok()
            .put("settings", settings)
            .put("services", db.rawQuery("SELECT id,name FROM services ORDER BY id", null).toJson())
            .put("invoices", invoices)
            .put("expenses", db.rawQuery("SELECT id,name,amount,date,category,notes FROM expenses ORDER BY date DESC, id DESC", null).toJson())
    }

    // ---------- الفواتير ----------

    private fun nextNum(db: SQLiteDatabase): Long {
        val counter = getSetting("next_num").toLongOrNull() ?: 1L
        val maxUsed = db.rawQuery("SELECT COALESCE(MAX(num),0) FROM invoices", null).use { it.moveToFirst(); it.getLong(0) }
        val n = maxOf(counter, maxUsed + 1)
        db.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES('next_num',?)", arrayOf<Any?>((n + 1).toString()))
        return n
    }

    fun saveInvoice(a: JSONObject): JSONObject {
        val items = a.getJSONArray("items")
        if (items.length() == 0) return err("أضف خدمة واحدة على الأقل")
        val db = writableDatabase
        db.beginTransaction()
        try {
            var total = 0L
            val rows = ArrayList<Triple<String, Double, Long>>()
            for (i in 0 until items.length()) {
                val r = items.getJSONObject(i)
                val name = r.getString("name").trim()
                val qty = r.getDouble("qty")
                val price = r.getLong("price")
                if (name.isEmpty() || qty <= 0.0 || price < 0L) return err("بيانات البند رقم ${i + 1} غير صحيحة")
                total += Math.round(qty * price)
                rows.add(Triple(name, qty, price))
            }
            if (total <= 0L) return err("إجمالي الفاتورة يجب أن يكون أكبر من صفر")
            val paid = a.optLong("paid", 0L)
            if (paid < 0L || paid > total) return err("المبلغ المدفوع أكبر من إجمالي الفاتورة")

            val num = nextNum(db)
            val date = today()
            val cv = ContentValues().apply {
                put("num", num); put("date", date); put("time", nowTime())
                put("customer", a.optString("customer").trim()); put("phone", a.optString("phone").trim())
                put("total", total); put("paid", paid)
                put("method", a.optString("method")); put("notes", a.optString("notes").trim())
                put("status", "active")
            }
            val id = db.insertOrThrow("invoices", null, cv)
            for ((name, qty, price) in rows) {
                db.execSQL(
                    "INSERT INTO items(invoice_id,name,qty,price,total) VALUES(?,?,?,?,?)",
                    arrayOf<Any?>(id, name, qty, price, Math.round(qty * price))
                )
            }
            if (paid > 0L) {
                db.execSQL(
                    "INSERT INTO payments(invoice_id,date,amount,method) VALUES(?,?,?,?)",
                    arrayOf<Any?>(id, date, paid, a.optString("method"))
                )
            }
            db.setTransactionSuccessful()
            return ok().put("id", id).put("num", num)
        } finally {
            db.endTransaction()
        }
    }

    fun addPayment(a: JSONObject): JSONObject {
        val id = a.getLong("id")
        val amt = a.getLong("amount")
        val db = writableDatabase
        db.beginTransaction()
        try {
            val row = db.rawQuery("SELECT total,paid,status FROM invoices WHERE id=?", arrayOf(id.toString())).use {
                if (it.moveToFirst()) Triple(it.getLong(0), it.getLong(1), it.getString(2)) else null
            } ?: return err("الفاتورة غير موجودة")
            if (row.third != "active") return err("لا يمكن تسجيل دفعة على فاتورة ملغاة")
            if (amt <= 0L || amt > row.first - row.second) return err("المبلغ غير صحيح أو أكبر من المتبقي")
            db.execSQL(
                "INSERT INTO payments(invoice_id,date,amount,method) VALUES(?,?,?,?)",
                arrayOf<Any?>(id, today(), amt, a.optString("method"))
            )
            db.execSQL("UPDATE invoices SET paid=paid+? WHERE id=?", arrayOf<Any?>(amt, id))
            db.setTransactionSuccessful()
            return ok()
        } finally {
            db.endTransaction()
        }
    }

    /** لا تُحذف الفواتير نهائياً؛ تُلغى وتبقى مسجلة حتى لا يتكرر الرقم ولا تضيع آثارها. */
    fun cancelInvoice(a: JSONObject): JSONObject {
        val n = writableDatabase.compileStatement("UPDATE invoices SET status='cancelled' WHERE id=? AND status='active'").run {
            bindLong(1, a.getLong("id")); executeUpdateDelete()
        }
        return if (n > 0) ok() else err("تعذر إلغاء الفاتورة")
    }

    // ---------- المصروفات والخدمات والإعدادات ----------

    fun saveExpense(a: JSONObject): JSONObject {
        val name = a.optString("name").trim()
        val amount = a.optLong("amount", 0L)
        val date = a.optString("date")
        if (name.isEmpty()) return err("اكتب اسم المصروف")
        if (amount <= 0L) return err("أدخل قيمة صحيحة للمصروف")
        if (!DATE_RE.matches(date)) return err("التاريخ غير صحيح")
        writableDatabase.execSQL(
            "INSERT INTO expenses(name,amount,date,category,notes) VALUES(?,?,?,?,?)",
            arrayOf<Any?>(name, amount, date, a.optString("category"), a.optString("notes").trim())
        )
        return ok()
    }

    fun saveService(a: JSONObject): JSONObject {
        val name = a.optString("name").trim()
        if (name.isEmpty()) return err("اكتب اسم الخدمة")
        val id = a.optLong("id", 0L)
        if (id > 0L) writableDatabase.execSQL("UPDATE services SET name=? WHERE id=?", arrayOf<Any?>(name, id))
        else writableDatabase.execSQL("INSERT INTO services(name) VALUES(?)", arrayOf<Any?>(name))
        return ok()
    }

    fun delete(table: String, id: Long): JSONObject {
        require(table == "expenses" || table == "services")
        writableDatabase.execSQL("DELETE FROM $table WHERE id=?", arrayOf<Any?>(id))
        return ok()
    }

    fun saveSettings(a: JSONObject): JSONObject {
        if (a.has("office_name") && a.optString("office_name").isBlank()) return err("اسم المكتب مطلوب")
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (k in EDITABLE) if (a.has(k)) db.execSQL(
                "INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", arrayOf<Any?>(k, a.optString(k).trim())
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return ok()
    }

    // ---------- النسخ الاحتياطي والاستعادة ----------

    fun exportJson(): String {
        val db = readableDatabase
        val tables = JSONObject()
        for ((t, cols) in COLS) {
            tables.put(t, db.rawQuery("SELECT ${cols.joinToString(",")} FROM $t ORDER BY ${cols[0]}", null).toJson())
        }
        return JSONObject().put("app", "maktabi").put("version", 1)
            .put("exported_at", "${today()} ${nowTime()}").put("tables", tables).toString()
    }

    /** يرجع عدد الفواتير المستعادة. يدعم صيغة النسخة الجديدة وصيغة النموذج الأولي القديم (مصفوفة فواتير). */
    fun restore(text: String): Int {
        val t = text.trim().removePrefix("\uFEFF")
        val data: Map<String, JSONArray> = if (t.startsWith("[")) {
            legacy(JSONArray(t))
        } else {
            val o = JSONObject(t)
            require(o.optString("app") == "maktabi") { "هذا ليس ملف نسخة احتياطية لتطبيق مكتبي" }
            val tb = o.getJSONObject("tables")
            COLS.keys.associateWith { tb.optJSONArray(it) ?: JSONArray() }
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (tbl in COLS.keys.reversed()) db.delete(tbl, null, null)
            for ((tbl, cols) in COLS) {
                val rows = data.getValue(tbl)
                for (i in 0 until rows.length()) {
                    val r = rows.getJSONObject(i)
                    val cv = ContentValues()
                    for (c in cols) {
                        if (!r.has(c) || r.isNull(c)) continue
                        when (val v = r.get(c)) {
                            is Int -> cv.put(c, v.toLong())
                            is Long -> cv.put(c, v)
                            is Double -> cv.put(c, v)
                            else -> cv.put(c, v.toString())
                        }
                    }
                    db.insertOrThrow(tbl, null, cv)
                }
            }
            ensureDefaults(db)
            val maxNum = db.rawQuery("SELECT COALESCE(MAX(num),0) FROM invoices", null).use { it.moveToFirst(); it.getLong(0) }
            val counter = getSetting("next_num").toLongOrNull() ?: 1L
            db.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES('next_num',?)", arrayOf<Any?>(maxOf(counter, maxNum + 1).toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return data.getValue("invoices").length()
    }

    /** تحويل نسخة النموذج الأولي (دنانير عشرية) إلى الصيغة الجديدة (دراهم صحيحة). */
    private fun legacy(arr: JSONArray): Map<String, JSONArray> {
        val inv = JSONArray(); val its = JSONArray(); val pay = JSONArray(); val svc = JSONArray()
        var itemId = 1L; var payId = 1L
        fun dirham(x: Double) = Math.round(x * 1000)
        DEFAULT_SERVICES.forEachIndexed { i, n -> svc.put(JSONObject().put("id", i + 1).put("name", n)) }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getLong("id")
            val items = o.optJSONArray("items") ?: JSONArray()
            var total = 0L
            for (j in 0 until items.length()) {
                val r = items.getJSONObject(j)
                val qty = r.optDouble("qty", 1.0)
                val price = dirham(r.optDouble("price", 0.0))
                val lt = Math.round(qty * price)
                total += lt
                its.put(JSONObject().put("id", itemId++).put("invoice_id", id).put("name", r.optString("name"))
                    .put("qty", qty).put("price", price).put("total", lt))
            }
            val date = o.optString("date", today())
            val paid = dirham(o.optDouble("paid", 0.0)).coerceIn(0L, total)
            var extra = 0L
            val ps = o.optJSONArray("payments")
            if (ps != null) for (j in 0 until ps.length()) {
                val p = ps.getJSONObject(j)
                val amt = dirham(p.optDouble("amount", 0.0))
                extra += amt
                pay.put(JSONObject().put("id", payId++).put("invoice_id", id).put("date", p.optString("date", date)).put("amount", amt).put("method", ""))
            }
            if (paid - extra > 0L) {
                pay.put(JSONObject().put("id", payId++).put("invoice_id", id).put("date", date).put("amount", paid - extra).put("method", o.optString("method")))
            }
            inv.put(JSONObject().put("id", id).put("num", id).put("date", date).put("time", o.optString("time"))
                .put("customer", o.optString("customer")).put("phone", o.optString("phone"))
                .put("total", total).put("paid", paid).put("method", o.optString("method"))
                .put("notes", o.optString("notes")).put("status", "active"))
        }
        return mapOf(
            "settings" to JSONArray(), "services" to svc, "invoices" to inv,
            "items" to its, "payments" to pay, "expenses" to JSONArray()
        )
    }
}
