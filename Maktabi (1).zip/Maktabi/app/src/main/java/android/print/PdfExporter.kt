package android.print

import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import java.io.File

/**
 * يكتب محتوى WebView مباشرة إلى ملف PDF.
 * موجود داخل حزمة android.print لأن LayoutResultCallback و WriteResultCallback
 * لا يمكن توريثهما إلا من داخل هذه الحزمة.
 */
class PdfExporter(private val adapter: PrintDocumentAdapter, private val attrs: PrintAttributes) {

    fun export(file: File, done: (Boolean) -> Unit) {
        adapter.onLayout(null, attrs, CancellationSignal(), object : PrintDocumentAdapter.LayoutResultCallback() {
            override fun onLayoutFinished(info: PrintDocumentInfo?, changed: Boolean) {
                val pfd = try {
                    ParcelFileDescriptor.open(
                        file,
                        ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
                    )
                } catch (e: Exception) { done(false); return }
                adapter.onWrite(arrayOf(PageRange.ALL_PAGES), pfd, CancellationSignal(), object : PrintDocumentAdapter.WriteResultCallback() {
                    override fun onWriteFinished(pages: Array<out PageRange>?) {
                        try { pfd.close() } catch (_: Exception) {}
                        adapter.onFinish()
                        done(true)
                    }
                    override fun onWriteFailed(error: CharSequence?) {
                        try { pfd.close() } catch (_: Exception) {}
                        done(false)
                    }
                })
            }
            override fun onLayoutFailed(error: CharSequence?) { done(false) }
        }, null)
    }
}
