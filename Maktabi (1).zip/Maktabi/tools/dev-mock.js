/* محاكاة بسيطة لجسر أندرويد لتجربة الواجهة في المتصفح فقط (غير مُضمَّنة في APK).
   الاستخدام: أضف <script src="../../../../tools/dev-mock.js"></script> قبل سكربت الصفحة، أو استخدمها في الاختبار الآلي. */
(function(){
  const db={settings:{office_name:'مكتب النجاح',office_desc:'للطباعة والتصوير',address:'',phone:'',footer:'شكراً لتعاملكم مع مكتب النجاح',currency:'د.ل',next_num:'1',last_backup:''},
    services:['تصوير أبيض وأسود','تصوير ملون','طباعة أبيض وأسود','طباعة ملونة','تغليف وتجليد','مسح ضوئي (سكانر)','خدمات أخرى'].map((n,i)=>({id:i+1,name:n})),
    invoices:[],expenses:[]};
  window.__db=db; window.__native=[];
  const ymd=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  const E=m=>({ok:false,error:m}), O=(x)=>Object.assign({ok:true},x||{});
  const H={
    getAll:()=>O(JSON.parse(JSON.stringify(db))),
    saveInvoice(a){
      if(!a.items.length)return E('أضف خدمة واحدة على الأقل');
      let total=0;const items=a.items.map(i=>{const t=Math.round(i.qty*i.price);total+=t;return{name:i.name,qty:i.qty,price:i.price,total:t}});
      if(total<=0)return E('إجمالي الفاتورة يجب أن يكون أكبر من صفر');
      if(a.paid<0||a.paid>total)return E('المبلغ المدفوع أكبر من إجمالي الفاتورة');
      const used=Math.max(0,...db.invoices.map(x=>x.num));const num=Math.max(+db.settings.next_num,used+1);db.settings.next_num=String(num+1);
      const id=(db.invoices.reduce((m,x)=>Math.max(m,x.id),0))+1,d=new Date();
      db.invoices.unshift({id,num,date:ymd(d),time:'10:30',customer:a.customer.trim(),phone:a.phone.trim(),total,paid:a.paid,method:a.method,notes:a.notes.trim(),status:'active',items,payments:a.paid>0?[{date:ymd(d),amount:a.paid,method:a.method}]:[]});
      return O({id,num});
    },
    addPayment(a){const x=db.invoices.find(i=>i.id===a.id);if(!x)return E('الفاتورة غير موجودة');if(x.status!=='active')return E('لا يمكن تسجيل دفعة على فاتورة ملغاة');
      if(a.amount<=0||a.amount>x.total-x.paid)return E('المبلغ غير صحيح أو أكبر من المتبقي');x.paid+=a.amount;x.payments.push({date:ymd(new Date()),amount:a.amount,method:a.method});return O()},
    cancelInvoice(a){const x=db.invoices.find(i=>i.id===a.id);if(!x||x.status!=='active')return E('تعذر إلغاء الفاتورة');x.status='cancelled';return O()},
    saveExpense(a){if(!a.name.trim())return E('اكتب اسم المصروف');if(a.amount<=0)return E('أدخل قيمة صحيحة للمصروف');
      db.expenses.unshift({id:db.expenses.length+1,name:a.name.trim(),amount:a.amount,date:a.date,category:a.category,notes:a.notes});return O()},
    deleteExpense(a){db.expenses=db.expenses.filter(x=>x.id!==a.id);return O()},
    saveService(a){if(!a.name.trim())return E('اكتب اسم الخدمة');if(a.id){db.services.find(s=>s.id===a.id).name=a.name.trim()}else db.services.push({id:db.services.length+20,name:a.name.trim()});return O()},
    deleteService(a){db.services=db.services.filter(s=>s.id!==a.id);return O()},
    saveSettings(a){if(!a.office_name.trim())return E('اسم المكتب مطلوب');Object.assign(db.settings,a);return O()},
    exportBackup(){window.__native.push('exportBackup');return O()},
    pickBackup(){window.__native.push('pickBackup');return O()},
    print(a){window.__native.push({print:a});return O()},
    sharePdf(a){window.__native.push({sharePdf:a});return O()}
  };
  window.Android={call:(m,a)=>JSON.stringify(H[m]?H[m](JSON.parse(a)):E('طلب غير معروف'))};
})();
